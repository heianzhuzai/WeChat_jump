## 微信跳一跳自动化app

### 操作说明

- 请确保手机连接并打开调试功能，双击 one_step_auto_beta1 文件即可

### FAQ

- 更多问题请查阅 [FAQ](https://github.com/wangshub/wechat_jump_game/wiki/FAQ)

